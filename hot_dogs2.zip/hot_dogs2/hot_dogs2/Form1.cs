﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hot_dogs2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           
            if (!checkBox1.Checked && !checkBox2.Checked &&
                !checkBox3.Checked && !checkBox4.Checked)
            {
                MessageBox.Show("Selecione um tipo de pão!");
            }

           
            else if (!checkBox5.Checked && !checkBox6.Checked &&
                     !checkBox7.Checked && !checkBox8.Checked)
            {
                MessageBox.Show("Selecione pelo menos um molho!");
            }

            
            else if (!checkBox9.Checked && !checkBox10.Checked &&
                     !checkBox11.Checked && !checkBox12.Checked)
            {
                MessageBox.Show("Selecione pelo menos um acompanhamento!");
            }

            
            else if (!checkBox13.Checked && !checkBox14.Checked &&
                     !checkBox15.Checked && !checkBox16.Checked)
            {
                MessageBox.Show("Selecione a quantidade de salsichas!");
            }

           
            else if (!checkBox17.Checked && !checkBox18.Checked &&
                     !checkBox19.Checked && !checkBox20.Checked)
            {
                MessageBox.Show("Selecione pelo menos um extra!");
            }

            else
            {
                string pedido = "SEU PEDIDO:\n\n";

             
                if (checkBox1.Checked)
                    pedido += "Pão: 4 Queijos\n";
                else if (checkBox2.Checked)
                    pedido += "Pão: Alho\n";
                else if (checkBox3.Checked)
                    pedido += "Pão: De Leite\n";
                else if (checkBox4.Checked)
                    pedido += "Pão: Tradicional\n";

              
                pedido += "\nMolhos:\n";
                if (checkBox5.Checked) pedido += "- Ketchup\n";
                if (checkBox6.Checked) pedido += "- Mostarda\n";
                if (checkBox7.Checked) pedido += "- Maionese\n";
                if (checkBox8.Checked) pedido += "- Da Casa\n";

             
                pedido += "\nAcompanhamentos:\n";
                if (checkBox9.Checked) pedido += "- Batata Frita\n";
                if (checkBox10.Checked) pedido += "- Nuggets\n";
                if (checkBox11.Checked) pedido += "- Torresmo\n";
                if (checkBox12.Checked) pedido += "- Aneis de Cebola\n";

            
                pedido += "\nQuantidade de Salsichas:\n";
                if (checkBox13.Checked)
                    pedido += "1\n";
                else if (checkBox14.Checked)
                    pedido += "2\n";
                else if (checkBox15.Checked)
                    pedido += "3\n";
                else if (checkBox16.Checked)
                    pedido += "4\n";

              
                pedido += "\nExtras:\n";
                if (checkBox17.Checked) pedido += "- Bacon\n";
                if (checkBox18.Checked) pedido += "- Calabresa\n";
                if (checkBox19.Checked) pedido += "- Milho\n";
                if (checkBox20.Checked) pedido += "- Purê\n";

                MessageBox.Show(pedido, "Pedido Finalizado");
            }
        }
    }
}
