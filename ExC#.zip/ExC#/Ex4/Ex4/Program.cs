﻿using System;

class Program
{
    static void Main()
    {
        double x, y, z;

        Console.Write("Digite o lado A: ");
        x = double.Parse(Console.ReadLine());
        Console.Write("Digite o lado B: ");
        y = double.Parse(Console.ReadLine());
        Console.Write("Digite o lado C: ");
        z = double.Parse(Console.ReadLine());

        if (x > 0 && y > 0 && z > 0 &&
            x < y + z && y < x + z && z < x + y)
        {
            if (x == y && y == z)
                Console.Write("TRIANGULO EQUILATERO");
            else if (x == y || x == z || y == z)
                Console.Write("TRIANGULO ISOSCELES");
            else
                Console.Write("TRIANGULO ESCALENO");
        }
        else
        {
            Console.Write("NAO FORMA TRIANGULO");
        }

        Console.ReadLine();
    }
}