﻿using System;

class Program
{
    static void Main()
    {
        int lados;
        double lado;

        Console.Write("Numero de lados: ");
        lados = int.Parse(Console.ReadLine());

        Console.Write("Medida do lado: ");
        lado = double.Parse(Console.ReadLine());

        if (lados == 3)
        {
            double area = (Math.Sqrt(3) / 4) * lado * lado;
            Console.WriteLine("TRIANGULO");
            Console.WriteLine("Area: " + area);
        }
        else if (lados == 4)
        {
            double area = lado * lado;
            Console.WriteLine("QUADRADO");
            Console.WriteLine("Area: " + area);
        }
        else if (lados == 5)
        {
            Console.WriteLine("PENTAGONO");
        }
        else if (lados < 3)
        {
            Console.WriteLine("NAO E UM POLIGONO");
        }
        else
        {
            Console.WriteLine("POLIGONO NAO IDENTIFICADO");
        }

        Console.ReadLine();
    }
}