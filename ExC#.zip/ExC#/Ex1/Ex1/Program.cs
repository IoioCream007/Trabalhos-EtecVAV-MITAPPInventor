﻿using System;

class Program
{
    static void Main()
    {
        double n1, n2, n3, n4;

        Console.Write("Digite o 1 numero: ");
        n1 = double.Parse(Console.ReadLine());
        Console.Write("Digite o 2 numero: ");
        n2 = double.Parse(Console.ReadLine());
        Console.Write("Digite o 3 numero: ");
        n3 = double.Parse(Console.ReadLine());
        Console.Write("Digite o 4 numero: ");
        n4 = double.Parse(Console.ReadLine());

        double maior = n1;
        double menor = n1;

        if (n2 > maior) maior = n2;
        if (n3 > maior) maior = n3;
        if (n4 > maior) maior = n4;

        if (n2 < menor) menor = n2;
        if (n3 < menor) menor = n3;
        if (n4 < menor) menor = n4;

        Console.WriteLine("Maior: " + maior);
        Console.WriteLine("Menor: " + menor);

        Console.ReadLine();
    }
}