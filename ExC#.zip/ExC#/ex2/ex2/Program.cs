﻿using System;

class Program
{
    static void Main()
    {
        int a, b, c, aux;

        Console.Write("Digite o 1 numero: ");
        a = int.Parse(Console.ReadLine());
        Console.Write("Digite o 2 numero: ");
        b = int.Parse(Console.ReadLine());
        Console.Write("Digite o 3 numero: ");
        c = int.Parse(Console.ReadLine());

        if (a < b) { aux = a; a = b; b = aux; }
        if (a < c) { aux = a; a = c; c = aux; }
        if (b < c) { aux = b; b = c; c = aux; }

        Console.WriteLine("Ordem decrescente: " + a + " " + b + " " + c);

        Console.ReadLine();
    }
}