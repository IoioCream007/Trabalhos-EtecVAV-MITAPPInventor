﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enem.galatic
{
    public partial class Pag10 : Form
    {
        public Pag10()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int resposta = -1;

            if (checkBox1.Checked) resposta = 0;
            else if (checkBox2.Checked) resposta = 1;
            else if (checkBox3.Checked) resposta = 2;
            else if (checkBox4.Checked) resposta = 3;
            else if (checkBox5.Checked) resposta = 4;

            if (resposta == -1)
            {
                MessageBox.Show("Selecione uma resposta!");
                return;
            }

            if (resposta == Quiz.respostasCorretas[9])
                Quiz.acertos++;

            MessageBox.Show(
                "Questionário Finalizado!\n\n" +
                "Você acertou: " + Quiz.acertos + " de 10 questões!"
            );

            Application.Exit();
        }
        }
    }
   

