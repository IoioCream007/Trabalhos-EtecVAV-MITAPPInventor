﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Enem.galatic
{
    public partial class Pag5 : Form
    {
        public Pag5()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int resposta = -1;

            if (checkBox1.Checked) resposta = 0;
            else if (checkBox2.Checked) resposta = 1;
            else if (checkBox3.Checked) resposta = 2;
            else if (checkBox4.Checked) resposta = 3;
            else if (checkBox5.Checked) resposta = 4;

            if (resposta == -1)
            {
                MessageBox.Show("Selecione uma resposta!");
                return;
            }

            if (resposta == Quiz.respostasCorretas[Quiz.perguntaAtual - 1])
                Quiz.acertos++;

            Quiz.perguntaAtual++;

            Form proximaTela = null;

            switch (Quiz.perguntaAtual)
            {
                case 2:
                    proximaTela = new Pag2();
                    break;

                case 3:
                    proximaTela = new Pag3();
                    break;

                case 4:
                    proximaTela = new Pag4();
                    break;

                case 5:
                    proximaTela = new Pag5();
                    break;

                case 6:
                    proximaTela = new Pag6();
                    break;

                case 7:
                    proximaTela = new Pag7();
                    break;

                case 8:
                    proximaTela = new Pag8();
                    break;

                case 9:
                    proximaTela = new Pag9();
                    break;

                case 10:
                    proximaTela = new Pag10();
                    break;
            }

            if (proximaTela != null)
            {
                proximaTela.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Fim do questionário!\nAcertos: " + Quiz.acertos + "/10");
                Application.Exit();
            }
        }
    }
    }

