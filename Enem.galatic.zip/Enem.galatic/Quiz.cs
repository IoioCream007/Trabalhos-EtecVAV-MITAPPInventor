﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enem.galatic
{
    internal class Quiz
    {
            public static int acertos = 0;
            public static int perguntaAtual = 1;

            public static int[] respostasCorretas =
            {
            0,
            1,
            2,
            3,
            4,
            0,
            1,
            2,
            3,
            4
        };
    }
}

