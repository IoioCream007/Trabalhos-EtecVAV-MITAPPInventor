﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_C_
{
    public partial class FormOrdem : Form
    {
        public FormOrdem()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n1, n2, n3;

           
            if (!int.TryParse(textBox1.Text, out n1) ||
                !int.TryParse(textBox2.Text, out n2) ||
                !int.TryParse(textBox3.Text, out n3))
            {
                MessageBox.Show("Digite apenas números!");
                return;
            }

            
            int maior = Math.Max(n1, Math.Max(n2, n3));
            int menor = Math.Min(n1, Math.Min(n2, n3));
            int meio = n1 + n2 + n3 - maior - menor;

           
            label1.Text = "Ordem: " + maior + " - " + meio + " - " + menor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
