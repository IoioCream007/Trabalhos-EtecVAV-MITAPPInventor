﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_C_
{
    public partial class FormPoligonos : Form
    {
        public FormPoligonos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int lados;
            double medida;

            if (!int.TryParse(textBox1.Text, out lados) ||
                !double.TryParse(textBox2.Text, out medida))
            {
                MessageBox.Show("Digite valores válidos!");
                return;
            }

            if (lados < 3)
            {
                label1.Text = "Não é um polígono";
            }
            else if (lados == 3)
            {
                double perimetro = medida * 3;
                label1.Text = "Triângulo - Perímetro: " + perimetro;
            }
            else if (lados == 4)
            {
                double area = medida * medida;
                label1.Text = "Quadrado - Área: " + area;
            }
            else if (lados == 5)
            {
                label1.Text = "Pentágono";
            }
            else
            {
                label1.Text = "Polígono não identificado";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
