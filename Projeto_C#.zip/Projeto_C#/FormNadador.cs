﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_C_
{
    public partial class FormNadador : Form
    {
        public FormNadador()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int idade;

            if (!int.TryParse(textBox1.Text, out idade))
            {
                MessageBox.Show("Digite uma idade válida!");
                return;
            }

            if (idade >= 5 && idade <= 7)
                label1.Text = "Infantil A";
            else if (idade <= 10)
                label1.Text = "Infantil B";
            else if (idade <= 13)
                label1.Text = "Juvenil A";
            else if (idade <= 17)
                label1.Text = "Juvenil B";
            else if (idade <= 25)
                label1.Text = "Sênior";
            else
                label1.Text = "Fora da faixa";
        }

        private void FormNadador_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
