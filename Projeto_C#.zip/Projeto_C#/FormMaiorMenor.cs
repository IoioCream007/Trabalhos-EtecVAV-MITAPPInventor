﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_C_
{
    public partial class FormMaiorMenor : Form
    {
        public FormMaiorMenor()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double n1, n2, n3, n4;

           
            if (!double.TryParse(textBox1.Text, out n1) ||
                !double.TryParse(textBox2.Text, out n2) ||
                !double.TryParse(textBox3.Text, out n3) ||
                !double.TryParse(textBox4.Text, out n4))
            {
                MessageBox.Show("Digite apenas números!");
                return;
            }

           
            double maior = n1;
            double menor = n1;

            if (n2 > maior) maior = n2;
            if (n3 > maior) maior = n3;
            if (n4 > maior) maior = n4;

            if (n2 < menor) menor = n2;
            if (n3 < menor) menor = n3;
            if (n4 < menor) menor = n4;

       
            label1.Text = "Maior: " + maior + " | Menor: " + menor;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
