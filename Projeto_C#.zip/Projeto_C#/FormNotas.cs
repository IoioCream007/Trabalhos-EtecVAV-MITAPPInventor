﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_C_
{
    public partial class FormNotas : Form
    {
        public FormNotas()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nome = textBox1.Text;

            double n1, n2, n3, media;

           
            if (!double.TryParse(textBox2.Text, out n1) ||
                !double.TryParse(textBox3.Text, out n2) ||
                !double.TryParse(textBox4.Text, out n3))
            {
                MessageBox.Show("Digite apenas números nas notas!");
                return;
            }

        
            media = (n1 + n2 + n3) / 3;

            if (media < 5)
                label1.Text = nome + " reprovado. Média: " + media.ToString("F2");
            else
                label1.Text = nome + " aprovado. Média: " + media.ToString("F2");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
