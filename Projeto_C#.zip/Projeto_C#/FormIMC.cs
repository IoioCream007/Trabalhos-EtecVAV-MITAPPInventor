﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_C_
{
    public partial class FormIMC : Form
    {
        public FormIMC()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double alt, peso, imc;

            if (!double.TryParse(textBox1.Text, out alt) ||
                !double.TryParse(textBox2.Text, out peso))
            {
                MessageBox.Show("Digite números!");
                return;
            }

            if (alt > 3)
            {
                alt = alt / 100;
            }

            imc = peso / (alt * alt);

            if (imc <= 18.5)
                label1.Text = "Muito Magro";
            else if (imc < 25)
                label1.Text = "Normal";
            else if (imc < 30)
                label1.Text = "Sobrepeso";
            else if (imc < 35)
                label1.Text = "Obesidade Grau 1";
            else if (imc < 40)
                label1.Text = "Obesidade Severa";
            else
                label1.Text = "Obesidade Mórbida";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
