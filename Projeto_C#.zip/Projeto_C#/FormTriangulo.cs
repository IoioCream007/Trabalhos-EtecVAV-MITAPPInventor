﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projeto_C_
{
    public partial class FormTriangulo : Form
    {
        public FormTriangulo()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double a, b, c;


            if (!double.TryParse(textBox1.Text, out a) ||
                !double.TryParse(textBox2.Text, out b) ||
                !double.TryParse(textBox3.Text, out c))
            {
                MessageBox.Show("Digite valores válidos!");
                return;
            }


            if (a < b + c && b < a + c && c < a + b)
            {
                if (a == b && b == c)
                {
                    label1.Text = "Triângulo Equilátero";
                    pictureBox1.Image = Image.FromFile("imagens/triangulo.png");
                }
                else if (a == b || a == c || b == c)
                {
                    label1.Text = "Triângulo Isósceles";
                    pictureBox1.Image = Image.FromFile("imagens/isosceles.png");
                }
                else
                {
                    label1.Text = "Triângulo Escaleno";
                    pictureBox1.Image = Image.FromFile("imagens/escaleno.png");
                }
            }
            else
            {
                label1.Text = "Não forma um triângulo";
                pictureBox1.Image = null;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
