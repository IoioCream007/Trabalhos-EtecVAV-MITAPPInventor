﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mani_string
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string frase = textFrase.Text;
            textTotal.Text = frase.Length.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string frase = textFrase.Text;    
             textEsp.Text = frase.Replace(" ","");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string frase = textFrase.Text;
            string invertida = "";

            for (int i = frase.Length - 1; i >= 0; i--)
            {
                invertida += frase[i];
            }
            textInv.Text = invertida;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string frase = textFrase.Text.ToUpper();

            int quantidadeA = 0;
            int quantidadeE = 0;
            int quantidadeI = 0;
            int quantidadeO = 0;
            int quantidadeU = 0;

            foreach (char Letra in frase)
            {
                if (Letra == 'A')
                {
                    quantidadeA++;
                }
                else if (Letra == 'E')
                {
                    quantidadeE++;
                }
                else if (Letra == 'I')
                {
                    quantidadeI++;
                }
                else if (Letra == 'O')
                {
                    quantidadeO++;
                }
                else if (Letra == 'U')
                {
                    quantidadeU++;
                }
            }
            textA.Text = quantidadeA.ToString();
            textE.Text = quantidadeE.ToString();
            textI.Text = quantidadeI.ToString();
            textO.Text = quantidadeO.ToString();
            textU.Text  = quantidadeU.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string frase = textFrase.Text;

            string  SemEspacos = frase.Replace(" ", "").ToLower();
            string invertida = "";

            for (int i = SemEspacos.Length - 1; i >= 0; i--)
            {
                invertida += SemEspacos[i];
            }

            if (SemEspacos == invertida)
            {
                MessageBox.Show("A frase é um palindromo!");
            }
            else
            {
                MessageBox.Show("A frase não é um palindromo!");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string frase = textFrase.Text;
            listLetra.Items.Clear();
            foreach (char letra in frase)
            {
                if(letra !=  ' ')
                {
                    listLetra.Items.Add(letra);
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string frase = textFrase.Text;

            listPalavra.Items.Clear();
            string[] palavras = frase.Split(
                new char[] { ' ' },
                StringSplitOptions.RemoveEmptyEntries
                );
            foreach (string palavra in palavras)
            {
                listPalavra.Items.Add(palavra);
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textFrase.Clear();
            textInv.Clear();
            textEsp.Clear();
            textTotal.Clear();

            textA.Clear();
            textE.Clear();
            textI.Clear();
            textO.Clear();
            textU.Clear();

            listLetra.Items.Clear();
            listPalavra.Items.Clear(); 

            textFrase.Focus();
        }
    }
}
