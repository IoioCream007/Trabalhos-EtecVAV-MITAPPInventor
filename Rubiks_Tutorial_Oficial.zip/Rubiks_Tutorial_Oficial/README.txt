RUBIK'S TUTORIAL — PHP + MYSQL

Estrutura:
- index.php
- tutoriais.php
- tutorial-3x3.php
- tutorial-2x2.php
- tutorial-5x5.php
- tutorial-pyraminx.php
- loja.php
- sobre.php
- login.php
- admin.php
- logout.php
- config.php
- auth.php
- script.js
- css/style.css
- api/auth.php
- api/produtos.php
- api/pedidos.php
- partials/header.php
- partials/footer.php
- database.sql

INSTALAÇÃO NO XAMPP
1. Coloque a pasta Rubiks_Tutorial_Completo dentro de C:/xampp/htdocs/
2. Abra o XAMPP e ligue Apache e MySQL.
3. Abra http://localhost/phpmyadmin
4. Importe o arquivo database.sql.
5. Abra http://localhost/Rubiks_Tutorial_Completo/

ADMIN
Login: admin
Senha: Admin@123

FUNCIONALIDADES
- Login administrativo com PHP Session + password_hash/password_verify.
- Produtos armazenados no MySQL.
- Cadastro e exclusão de produtos.
- Loja carregada pela API PHP.
- Carrinho no navegador.
- Finalização de pedido registrada no MySQL.
- Estoque reduzido ao finalizar.
- Tema claro/escuro.
- Front-end preservado com o CSS fornecido.

OBSERVAÇÃO
O checkout registra o pedido no banco, mas não processa pagamento real.
