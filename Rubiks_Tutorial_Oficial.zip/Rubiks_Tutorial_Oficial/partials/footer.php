<footer><div class="footer-inner"><div class="brand"><span class="brand-cube"><span></span><span></span><span></span><span></span></span><span><strong>Rubik's</strong><small>Tutorial</small></span></div><p>Aprenda. Pratique. Resolva.</p><span>© 2026 Rubik's Tutorial</span></div></footer>
<div class="modal-backdrop" id="modalBackdrop"><div class="modal">
<button class="modal-close" id="modalClose">×</button><div class="modal-logo">✦</div>
<span class="eyebrow">ACESSO</span><h2>Entrar na conta</h2><p>Clientes podem acessar normalmente. O login administrativo libera a página de gerenciamento.</p>
<form id="authForm"><label>Login<input id="authUser" type="text" placeholder="Seu login" required></label><label>Senha<input id="authPass" type="password" placeholder="Sua senha" required></label><button class="btn btn-accent btn-full" type="submit">Entrar</button></form>
<div class="form-note">Acesso administrativo: <strong>admin</strong> / <strong>Admin@123</strong></div>
</div></div>
<div class="cart-backdrop" id="cartBackdrop"><div class="cart-modal"><button class="modal-close" id="cartClose">×</button><span class="eyebrow">SEU CARRINHO</span><h2>Suas compras</h2><div id="cartItems" class="cart-items"></div><div class="cart-total"><span>Total</span><strong id="cartTotal">R$ 0,00</strong></div><button class="btn btn-accent btn-full" id="checkoutBtn">Finalizar compra</button><small class="form-note">O pedido será registrado no banco de dados.</small></div></div>
<div class="toast" id="toast"></div>
<script src="script.js"></script>
</body></html>