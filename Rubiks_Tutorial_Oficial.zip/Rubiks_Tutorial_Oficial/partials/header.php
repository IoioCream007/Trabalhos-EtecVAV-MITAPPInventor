<?php
require_once __DIR__ . '/../auth.php';
$active = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle ?? "Rubik's Tutorial") ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head><body>
<header class="topbar">
<a href="index.php" class="brand"><span class="brand-cube"><span></span><span></span><span></span><span></span></span><span><strong>Rubik's</strong><small>Tutorial</small></span></a>
<nav class="desktop-nav">
<a class="<?= $active==='index.php'?'active':'' ?>" href="index.php">Início</a>
<a class="<?= $active==='tutoriais.php'?'active':'' ?>" href="tutoriais.php">Tutoriais</a>
<a class="<?= $active==='loja.php'?'active':'' ?>" href="loja.php">Loja</a>
<a class="<?= $active==='sobre.php'?'active':'' ?>" href="sobre.php">Sobre</a>
<?php if (is_admin()): ?><a class="<?= $active==='admin.php'?'active':'' ?>" href="admin.php">Adicionar produtos</a><?php endif; ?>
</nav>
<div class="header-actions">
<button class="icon-btn" id="themeBtn">☼</button>
<?php if (is_admin()): ?><span class="admin-pill" style="display:inline-flex">ADMIN</span><?php endif; ?>
<button class="cart-btn" id="cartBtn">🛒 <span id="cartCount">0</span></button>
<?php if (is_admin()): ?><a class="btn btn-ghost" href="logout.php">Sair</a><?php else: ?><button class="btn btn-ghost" id="loginBtn">Entrar</button><?php endif; ?>
<button class="menu-btn" id="menuBtn">☰</button>
</div></header>
<nav class="mobile-menu" id="mobileMenu">
<a href="index.php">Início</a><a href="tutoriais.php">Tutoriais</a><a href="loja.php">Loja</a><a href="sobre.php">Sobre</a>
<?php if (is_admin()): ?><a href="admin.php">Adicionar produtos</a><a href="logout.php">Sair</a><?php endif; ?>
</nav>
