<?php
require_once __DIR__.'/auth.php';
require_admin();
require_once __DIR__.'/config.php';
$products=db()->query("SELECT * FROM produtos WHERE ativo=1 ORDER BY id DESC")->fetchAll();
$pageTitle="Rubik's Tutorial | Administração";
require __DIR__.'/partials/header.php';
?>
<main class="page"><div class="section-shell"><div class="page-head"><div><span class="eyebrow">ÁREA ADMINISTRATIVA</span><h1>Adicionar <span>produtos.</span></h1></div><p>Os produtos são salvos diretamente no MySQL.</p></div>
<div class="admin-layout"><section class="admin-card"><h2>Novo produto</h2><p>Preencha os campos e clique em adicionar.</p>
<form id="productForm"><div class="form-grid"><div class="field"><label>Nome</label><input id="pName" required placeholder="Ex.: Speed Cube 4×4"></div><div class="field"><label>Preço</label><input id="pPrice" type="number" step="0.01" min="0" required placeholder="59.90"></div><div class="field"><label>Tipo visual</label><select id="pType"><option value="3x3">Cubo</option><option value="2x2">Cubo compacto</option><option value="5x5">Cubo avançado</option><option value="pyr">Pyraminx</option></select></div><div class="field"><label>Etiqueta</label><input id="pTag" placeholder="Novo"></div><div class="field"><label>Estoque</label><input id="pStock" type="number" min="0" value="10"></div><div class="field full"><label>Descrição</label><textarea id="pDesc" placeholder="Descrição do produto"></textarea></div></div><div class="admin-actions"><button class="btn btn-accent" type="submit">Adicionar produto</button><a class="btn btn-ghost" href="logout.php">Sair</a></div></form>
<div class="admin-note">A autenticação é feita por sessão PHP e a senha do administrador fica armazenada com hash no banco.</div></section>
<section class="admin-card"><h2>Produtos cadastrados</h2><p>Gerencie os produtos disponíveis na Loja.</p><div class="inventory" id="inventory">
<?php foreach($products as $p): ?><div class="inventory-item" data-id="<?=$p['id']?>"><div><strong><?=htmlspecialchars($p['nome'])?></strong><span><?=number_format((float)$p['preco'],2,',','.')?> · Estoque: <?=$p['estoque']?> · <?=htmlspecialchars($p['tag'])?></span></div><button class="delete-product" data-id="<?=$p['id']?>">Excluir</button></div><?php endforeach; ?>
</div></section></div></div></main>
<?php require __DIR__.'/partials/footer.php'; ?>