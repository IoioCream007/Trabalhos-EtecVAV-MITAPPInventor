<?php
require_once __DIR__.'/config.php';
require_once __DIR__.'/auth.php';
if (is_admin()) { header('Location: admin.php'); exit; }
$error = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $login=trim($_POST['login']??''); $senha=$_POST['senha']??'';
    $stmt=db()->prepare("SELECT * FROM usuarios WHERE login=? LIMIT 1"); $stmt->execute([$login]); $u=$stmt->fetch();
    if ($u && password_verify($senha,$u['senha']) && $u['tipo']==='admin') {
        $_SESSION['admin_id']=$u['id']; $_SESSION['admin_nome']=$u['nome']; header('Location: admin.php'); exit;
    }
    $error='Login ou senha inválidos.';
}
$pageTitle="Rubik's Tutorial | Login";
require __DIR__.'/partials/header.php';
?>
<main class="page"><div class="section-shell"><div class="modal" style="margin:0 auto"><div class="modal-logo">✦</div><span class="eyebrow">ACESSO ADMINISTRATIVO</span><h2>Entrar na conta</h2><p>Entre para gerenciar os produtos da Loja.</p>
<?php if($error): ?><div class="admin-note"><?=htmlspecialchars($error)?></div><?php endif; ?>
<form method="post"><label>Login<input name="login" required placeholder="Seu login"></label><label>Senha<input name="senha" type="password" required placeholder="Sua senha"></label><button class="btn btn-accent btn-full" type="submit">Entrar</button></form>
<?php require __DIR__.'/partials/footer.php'; ?>