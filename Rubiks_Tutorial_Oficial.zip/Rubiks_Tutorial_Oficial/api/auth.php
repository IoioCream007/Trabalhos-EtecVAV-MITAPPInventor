<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST') json_response(['success'=>false],405);
$data=json_decode(file_get_contents('php://input'),true)??[];
$login=trim($data['login']??''); $senha=$data['senha']??'';
$stmt=db()->prepare("SELECT * FROM usuarios WHERE login=? LIMIT 1"); $stmt->execute([$login]); $u=$stmt->fetch();
if(!$u || !password_verify($senha,$u['senha']) || $u['tipo']!=='admin') json_response(['success'=>false,'message'=>'Login ou senha inválidos.'],401);
session_regenerate_id(true); $_SESSION['admin_id']=$u['id']; $_SESSION['admin_nome']=$u['nome'];
json_response(['success'=>true]);
