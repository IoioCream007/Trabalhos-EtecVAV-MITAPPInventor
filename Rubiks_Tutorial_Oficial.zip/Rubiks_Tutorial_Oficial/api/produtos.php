<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../auth.php';
$method=$_SERVER['REQUEST_METHOD'];
if($method==='GET'){
  $rows=db()->query("SELECT id,nome,preco,descricao,tag,tipo,estoque FROM produtos WHERE ativo=1 ORDER BY id")->fetchAll();
  json_response(['success'=>true,'produtos'=>$rows]);
}
if(!is_admin()) json_response(['success'=>false,'message'=>'Não autorizado.'],401);
$data=json_decode(file_get_contents('php://input'),true)??$_POST;
if($method==='POST'){
  $stmt=db()->prepare("INSERT INTO produtos(nome,preco,descricao,tag,tipo,estoque) VALUES(?,?,?,?,?,?)");
  $stmt->execute([trim($data['nome']??''),(float)($data['preco']??0),trim($data['descricao']??''),trim($data['tag']??'Novo'),$data['tipo']??'3x3',(int)($data['estoque']??0)]);
  json_response(['success'=>true,'id'=>db()->lastInsertId()]);
}
if($method==='DELETE'){
  $id=(int)($data['id']??0); $stmt=db()->prepare("UPDATE produtos SET ativo=0 WHERE id=?"); $stmt->execute([$id]); json_response(['success'=>true]);
}
json_response(['success'=>false,'message'=>'Método inválido.'],405);
