<?php
require_once __DIR__.'/../config.php';
require_once __DIR__.'/../auth.php';
if($_SERVER['REQUEST_METHOD']!=='POST') json_response(['success'=>false],405);
$data=json_decode(file_get_contents('php://input'),true)??[];
$items=$data['items']??[];
if(!$items) json_response(['success'=>false,'message'=>'Carrinho vazio.'],422);
$pdo=db(); $pdo->beginTransaction();
try {
  $total=0; $normalized=[];
  $find=$pdo->prepare("SELECT id,nome,preco,estoque FROM produtos WHERE id=? AND ativo=1 FOR UPDATE");
  foreach($items as $it){
    $id=(int)($it['id']??0); $q=max(1,(int)($it['quantity']??1));
    $find->execute([$id]); $p=$find->fetch();
    if(!$p || $p['estoque']<$q) throw new RuntimeException('Produto sem estoque suficiente.');
    $sub=(float)$p['preco']*$q; $total+=$sub;
    $normalized[]=[$p,$q,$sub];
  }
  $stmt=$pdo->prepare("INSERT INTO pedidos(cliente_id,total) VALUES(?,?)");
  $stmt->execute([$_SESSION['admin_id']??null,$total]); $orderId=$pdo->lastInsertId();
  $ins=$pdo->prepare("INSERT INTO pedido_itens(pedido_id,produto_id,nome_produto,preco,quantidade,subtotal) VALUES(?,?,?,?,?,?)");
  $upd=$pdo->prepare("UPDATE produtos SET estoque=estoque-? WHERE id=?");
  foreach($normalized as [$p,$q,$sub]){$ins->execute([$orderId,$p['id'],$p['nome'],$p['preco'],$q,$sub]);$upd->execute([$q,$p['id']]);}
  $pdo->commit(); json_response(['success'=>true,'pedido_id'=>$orderId,'total'=>$total]);
} catch(Throwable $e){$pdo->rollBack();json_response(['success'=>false,'message'=>$e->getMessage()],422);}
