<?php
require_once __DIR__.'/config.php';
$pageTitle="Rubik's Tutorial | Loja";
require __DIR__.'/partials/header.php';
?>
<main class="page"><div class="section-shell"><div class="page-head"><div><span class="eyebrow">LOJA RUBIK'S</span><h1>Compre seu <span>próximo desafio.</span></h1></div><p>Produtos cadastrados pelo administrador aparecem aqui automaticamente.</p></div>
<div class="product-grid" id="productGrid"><p class="status">Carregando produtos...</p></div></div></main>
<?php require __DIR__.'/partials/footer.php'; ?>