CREATE DATABASE IF NOT EXISTS rubiks_tutorial CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rubiks_tutorial;

CREATE TABLE IF NOT EXISTS usuarios (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  login VARCHAR(60) NOT NULL UNIQUE,
  senha VARCHAR(255) NOT NULL,
  tipo ENUM('admin','cliente') NOT NULL DEFAULT 'cliente',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS produtos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(150) NOT NULL,
  preco DECIMAL(10,2) NOT NULL DEFAULT 0,
  descricao TEXT,
  tag VARCHAR(60) DEFAULT 'Novo',
  tipo VARCHAR(20) NOT NULL DEFAULT '3x3',
  estoque INT NOT NULL DEFAULT 0,
  ativo TINYINT(1) NOT NULL DEFAULT 1,
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pedidos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  cliente_id INT UNSIGNED NULL,
  total DECIMAL(10,2) NOT NULL DEFAULT 0,
  status ENUM('recebido','processando','enviado','cancelado') NOT NULL DEFAULT 'recebido',
  criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_pedido_cliente FOREIGN KEY (cliente_id) REFERENCES usuarios(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pedido_itens (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pedido_id INT UNSIGNED NOT NULL,
  produto_id INT UNSIGNED NULL,
  nome_produto VARCHAR(150) NOT NULL,
  preco DECIMAL(10,2) NOT NULL,
  quantidade INT NOT NULL,
  subtotal DECIMAL(10,2) NOT NULL,
  CONSTRAINT fk_item_pedido FOREIGN KEY (pedido_id) REFERENCES pedidos(id) ON DELETE CASCADE,
  CONSTRAINT fk_item_produto FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE SET NULL
) ENGINE=InnoDB;

INSERT INTO usuarios (nome, login, senha, tipo)
VALUES ('Administrador', 'admin', '$2y$12$aHWqtl6HmQUyNT90h64SJuW0MBOzSF0T.Nxg/nYzcXW96eEbZ68Tu', 'admin')
ON DUPLICATE KEY UPDATE senha=VALUES(senha), tipo='admin';

INSERT INTO produtos (nome, preco, descricao, tag, tipo, estoque) VALUES
('Speed Cube 3×3',49.90,'Perfeito para começar e evoluir sua velocidade.','Mais vendido','3x3',20),
('Speed Cube 2×2',34.90,'Compacto, rápido e ótimo para treinar.','Iniciante','2x2',20),
('Speed Cube 5×5',79.90,'Para quem quer dominar um desafio maior.','Avançado','5x5',10),
('Pyraminx',44.90,'Uma nova forma de desafiar suas habilidades.','Diferente','pyr',15)
ON DUPLICATE KEY UPDATE nome=VALUES(nome);
