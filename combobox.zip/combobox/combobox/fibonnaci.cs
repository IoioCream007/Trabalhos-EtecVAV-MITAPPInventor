﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace combobox
{
    public partial class fibonnaci : Form
    {
        public fibonnaci()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int quantidade;
            int primeiro = 0;
            int segundo = 1;
            int proximo;

            quantidade = Convert.ToInt32(textBox1.Text);

            listBox1.Items.Clear();

            for (int i = 0; i < quantidade; i++)
            {
                listBox1.Items.Add(primeiro);

                proximo = primeiro + segundo;

                primeiro = segundo;
                segundo = proximo;
            }
        }
    }
}
