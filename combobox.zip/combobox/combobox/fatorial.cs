﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace combobox
{
    public partial class fatorial : Form
    {
        public fatorial()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numero;
            int fatorial = 1;

            numero = Convert.ToInt32(textBox1.Text);

            if (numero == 0)
            {
                MessageBox.Show("0! = 1");
            }
            else
            {
                for (int i = 1; i <= numero; i++)
                {
                    fatorial = fatorial * i;
                }

                MessageBox.Show(numero + "! = " + fatorial);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
