﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace combobox
{
    public partial class posicao : Form
    {
        string[] numeros = new string[100];
        public posicao()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int limite;

            limite = Convert.ToInt32(textBox1.Text);

            listBox1.Items.Clear();

            for (int i = 0; i < limite; i++)
            {
                numeros[i] = Convert.ToString(i + 1);

                listBox1.Items.Add(numeros[i]);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int posicao;

            posicao = Convert.ToInt32(textBox2.Text);

            Resultado.Text = numeros[posicao];
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
