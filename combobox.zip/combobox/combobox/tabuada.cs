﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace combobox
{
    public partial class tabuada : Form
    {
        public tabuada()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int numero;

            numero = Convert.ToInt32(textbox1.Text);

            listBox1.Items.Clear();

            for (int i = 0; i <= 10; i++)
            {
                listBox1.Items.Add(numero + " x " + i + " = " + (numero * i));
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
