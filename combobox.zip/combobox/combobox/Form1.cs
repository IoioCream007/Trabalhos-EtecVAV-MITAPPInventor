﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace combobox
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exerciciosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void tabuadaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            tabuada tela = new tabuada();
            tela.Show();
        }

        private void incrementoToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            incremento tela = new incremento();
            tela.Show();
        }
        private void fatorialToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fatorial tela = new fatorial();
            tela.Show();
        }

        private void fibonacciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fibonnaci tela = new fibonnaci();
            tela.Show();
        }

        private void posiçãoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            posicao tela = new posicao();
            tela.Show();
        }

        private void incrementoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            incremento tela = new incremento();
            tela.Show();
        }

        private void sobreToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Projeto feito por Igor Ryan e Arthur Mendes");
        }
    }
}
