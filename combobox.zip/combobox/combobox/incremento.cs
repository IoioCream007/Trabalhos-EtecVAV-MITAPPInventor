﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace combobox
{
    public partial class incremento : Form
    {
        public incremento()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int inicial;
            int final;
            int incremento;

            inicial = Convert.ToInt32(textBox1.Text);
            final = Convert.ToInt32(textBox2.Text);
            incremento = Convert.ToInt32(textBox3.Text);

            listBox1.Items.Clear();

            for (int i = inicial; i <= final; i = i + incremento)
            {
                listBox1.Items.Add(i);
            }
        }
    }
}
