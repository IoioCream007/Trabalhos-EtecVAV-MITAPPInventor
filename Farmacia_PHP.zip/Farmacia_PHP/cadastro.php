<?php
require_once 'config/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nome = $_POST['nome'] ?? '';
  $laboratorio = $_POST['laboratorio'] ?? '';
  $descricao = $_POST['descricao'] ?? '';
  $quantidade = isset($_POST['quantidade']) ? (int)$_POST['quantidade'] : 0;
  $preco = isset($_POST['preco']) ? (float)$_POST['preco'] : 0.0;

  $stmt = $pdo->prepare("INSERT INTO produtos (nome, laboratorio, descricao, quantidade, preco) VALUES (?, ?, ?, ?, ?)");
  $stmt->execute([$nome, $laboratorio, $descricao, $quantidade, $preco]);

  header('Location: index.php');
  exit;
}
require_once 'includes/header.php';
?>

<main class="container">
  <h2>Cadastro de Produto</h2>

  <form action="cadastro.php" method="post" class="form" autocomplete="off">
    <div>
      <label>Nome</label>
      <input type="text" name="nome" required>
    </div>
    <div>
      <label>Laboratório</label>
      <input type="text" name="laboratorio">
    </div>
    <div>
      <label>Descrição</label>
      <textarea name="descricao"></textarea>
    </div>
    <div>
      <label>Quantidade</label>
      <input type="number" name="quantidade" min="0" required>
    </div>
    <div>
      <label>Preço</label>
      <input type="number" step="0.01" name="preco" min="0" required>
    </div>
    <button type="submit" class="btn">Salvar</button>
  </form>
</main>

<?php include 'includes/footer.php'; ?>