CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    laboratorio VARCHAR(100),
    descricao TEXT,
    quantidade INT NOT NULL,
    preco DECIMAL(10,2) NOT NULL
)