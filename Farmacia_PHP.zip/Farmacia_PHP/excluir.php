<?php
require_once 'config/conexao.php';

$id = $_GET['id'] ?? null;
if ($id) {
  $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
  $stmt->execute([$id]);
}
header('Location: index.php');
exit;