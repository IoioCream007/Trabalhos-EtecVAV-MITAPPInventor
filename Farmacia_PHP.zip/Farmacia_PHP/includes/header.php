<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Farmácia - Estoque</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="site-header" role="banner">
    <div class="container header-inner">
      <h1 class="brand">Gerenciamento de Estoque</h1>
      <nav class="main-nav" aria-label="Navegação principal">
        <a href="index.php" class="nav-link">Estoque</a>
        <a href="cadastro.php" class="nav-link">Adicionar Produto</a>
      </nav>
    </div>
  </header>