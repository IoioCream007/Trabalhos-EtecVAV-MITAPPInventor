  <footer class="site-footer" role="contentinfo">
    <div class="container" aria-label="Rodapé">
      <p>© <?php echo date('Y'); ?> Farmácia. Todos os direitos reservados.</p>
    </div>
  </footer>
</body>
</html>