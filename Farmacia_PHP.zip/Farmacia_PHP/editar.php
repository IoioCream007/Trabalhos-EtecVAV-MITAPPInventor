<?php
require_once 'config/conexao.php';

$id = $_GET['id'] ?? null;
if (!$id) {
  header('Location: index.php');
  exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $nome = $_POST['nome'] ?? '';
  $laboratorio = $_POST['laboratorio'] ?? '';
  $descricao = $_POST['descricao'] ?? '';
  $quantidade = isset($_POST['quantidade']) ? (int)$_POST['quantidade'] : 0;
  $preco = isset($_POST['preco']) ? (float)$_POST['preco'] : 0.0;

  $stmt = $pdo->prepare("UPDATE produtos SET nome=?, laboratorio=?, descricao=?, quantidade=?, preco=? WHERE id=?");
  $stmt->execute([$nome, $laboratorio, $descricao, $quantidade, $preco, $id]);
  header('Location: index.php');
  exit;
}

$stmt = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
$stmt->execute([$id]);
$produto = $stmt->fetch();

require_once 'includes/header.php';
?>

<main class="container">
  <h2>Editar Produto</h2>

  <?php if ($produto): ?>
  <form action="editar.php?id=<?= $id ?>" method="post" class="form" autocomplete="off">
    <div>
      <label>Nome</label>
      <input type="text" name="nome" value="<?= htmlspecialchars($produto['nome']) ?>" required>
    </div>
    <div>
      <label>Laboratório</label>
      <input type="text" name="laboratorio" value="<?= htmlspecialchars($produto['laboratorio'] ?? '') ?>">
    </div>
    <div>
      <label>Descrição</label>
      <textarea name="descricao"><?= htmlspecialchars($produto['descricao'] ?? '') ?></textarea>
    </div>
    <div>
      <label>Quantidade</label>
      <input type="number" name="quantidade" min="0" value="<?= (int)($produto['quantidade'] ?? 0) ?>" required>
    </div>
    <div>
      <label>Preço</label>
      <input type="number" step="0.01" name="preco" min="0" value="<?= number_format((float)($produto['preco'] ?? 0), 2, '.', '') ?>" required>
    </div>
    <button type="submit" class="btn">Atualizar</button>
  </form>
  <?php else: ?>
  <p>Produto não encontrado.</p>
  <?php endif; ?>
</main>

<?php include 'includes/footer.php'; ?>