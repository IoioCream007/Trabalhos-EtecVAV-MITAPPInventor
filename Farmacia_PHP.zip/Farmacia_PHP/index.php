<?php
require_once 'config/conexao.php';
require_once 'includes/header.php';
?>

<main class="container">
  <h2>Estoque de Produtos</h2>

  <div class="grid">
  <?php
  $stmt = $pdo->query("SELECT * FROM produtos ORDER BY nome ASC");
  while ($row = $stmt->fetch()) {
    echo '<div class="card">';
    echo '<h3>' . htmlspecialchars($row['nome']) . '</h3>';
    echo '<p><strong>Laboratório:</strong> ' . htmlspecialchars($row['laboratorio'] ?? '') . '</p>';
    echo '<p><strong>Estoque:</strong> ' . (int)$row['quantidade'] . '</p>';
    echo '<p><strong>Preço:</strong> R$ ' . number_format((float)$row['preco'], 2, ',', '.') . '</p>';
    echo '<p><a class="btn" href="editar.php?id=' . $row['id'] . '">Editar</a>';
    echo ' <a class="btn secondary" href="excluir.php?id=' . $row['id'] . '" onclick="return confirm(\'Excluir este item?\')">Excluir</a></p>';
    echo '</div>';
  }
  ?>
  </div>
</main>

<?php
include 'includes/footer.php';
?>